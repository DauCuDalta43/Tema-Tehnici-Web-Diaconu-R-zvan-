
function addlotto()
{
    const gridItems = gridContainer.querySelectorAll('.grid-item');

        if (gridItems.length > 0) {
            const randomIndex = Math.floor(Math.random() * 4);
        const randomItem = gridItems[randomIndex];
        const clone = randomItem.cloneNode(true);
        gridContainer.appendChild(clone);
        }
}



document.getElementById('username').textContent = localStorage.getItem('username');
const button = document.getElementById('b');
const gridContainer = document.getElementById('gc');

document.addEventListener('keydown', function(event)
{
    const key=event.key;
    if(key=='a')
    {var gridItems = gridContainer.querySelectorAll('.grid-item');
     for(let i = 1; i+7<gridItems.length; i++)
        { 
            ///console.log(i+gridItems.length);
            const lastItem=gridItems[gridItems.length-i];
            gridContainer.removeChild(lastItem);
        }
    }
    else
    {
        var gridItems = gridContainer.querySelectorAll('.grid-item');
        const lastItem=gridItems[gridItems.length-1];
        gridContainer.removeChild(lastItem);
    }
});
let hihi=setInterval(addlotto,1000);

// public/script.js
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('postForm');
    const textBox = document.getElementById('textBox');
    const messageDiv = document.getElementById('message');
    const postsDiv = document.getElementById('posts');
  
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const text = textBox.value;
      const regex = /lotto/i; // Case-insensitive regex to check for the word 'lotto'
  
      if (regex.test(text)) {
        try {
          const response = await fetch('/post-text', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text })
          });
  
          if (response.ok) {
            messageDiv.textContent = 'Text successfully posted!';
            messageDiv.style.color = 'green';
            textBox.value = '';
            loadPosts(); // Refresh the list of posts
          } else {
            messageDiv.textContent = 'Failed to post text.';
            messageDiv.style.color = 'red';
          }
        } catch (error) {
          messageDiv.textContent = 'Error: ' + error.message;
          messageDiv.style.color = 'red';
        }
      } else {
        messageDiv.textContent = 'Text does not contain the required word.';
        messageDiv.style.color = 'red';
      }
    });
  
    // Function to load posts from the server
    async function loadPosts() {
      try {
        const response = await fetch('/get-posts');
        if (response.ok) {
          const data = await response.json();
          postsDiv.innerHTML = data.posts.map(post => `<p>${post}</p>`).join('');
        } else {
          postsDiv.innerHTML = 'Failed to load posts.';
        }
      } catch (error) {
        postsDiv.innerHTML = 'Error: ' + error.message;
      }
    }
  
    // Initial load of posts
    
  });
  loadPosts();