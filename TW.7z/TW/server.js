require('dotenv').config();
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(session({
  secret: 'your-secret-key', // Replace with your secret key
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Set to true if using HTTPS
}));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Function to read user data from JSON file
const getUserData = () => {
  const data = fs.readFileSync('users.json');
  return JSON.parse(data).users;
};


app.get('/', (req, res) => {
  if (req.session.user) {
    res.sendFile(path.join(__dirname, 'public/' + 'a.html'));
  } else {
    res.sendFile(path.join(__dirname, 'login.html'));
  }
});


app.post('/post-text', (req, res) => {
    const { text } = req.body;
    const regex = /lotto/i; 
    if (regex.test(text)) {
      const data = JSON.parse(fs.readFileSync('data.json', 'utf8'));
      data.posts.push(text);
      fs.writeFileSync('data.json', JSON.stringify(data, null, 2));
      res.status(200).send('Buna sugestie');
    } else {
      res.status(400).send('Mai incearca');
    }
  });

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const users = getUserData();
  if (users[username] && users[username].password === password) {
    req.session.user = username;
    res.redirect('/');
  } else {
    res.send('Invalid username or password. <a href="/">Try again</a>');
  }
});

app.get('/get-posts', (req, res) => {
    const data = JSON.parse(fs.readFileSync('data.json', 'utf8'));
    res.json(data);
  });

app.get('/logout', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      return res.send('Error logging out');
    }
    res.redirect('/');
  });
});

app.use((req, res, next) => {
    res.status(404).sendFile(path.join(__dirname, 'public/', '404.html'));
  });

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
