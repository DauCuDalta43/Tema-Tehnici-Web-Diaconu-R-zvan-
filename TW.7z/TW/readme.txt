date login: user1, password1
apasati tasta a pentru a sterge toate listarile noi sau orice alta tasta pentru a sterge ultima
ar accepta teoretic in post doar texte care contin cuvantul lotto
imi pare rau pentru ora intarziata, am fost toata seara plecat pe tren si n-am avut pic de semnal :(